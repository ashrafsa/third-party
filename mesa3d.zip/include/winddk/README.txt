The gallium d3d10umd statetracker depends upon the follow Windows DDK headers
being placed here:

  d3d10tokenizedprogramformat.hpp
  d3d10umddi.h
  d3d11tokenizedprogramformat.hpp
  d3dkmddi.h
  d3dkmdt.h
  d3dkmthk.h
  d3dukmdt.h
  d3dumddi.h
  dxgiddi.h
  dxgiformat.h
  dxgitype.h
  dxmini.h
  wmidata.h
